# eoAPI Notifier Helm Chart

Helm chart for eoAPI Notifier — forwards PostgreSQL/pgSTAC change notifications to MQTT and/or CloudEvents outputs.

## Installation

```bash
# Install latest
helm install eoapi-notifier oci://ghcr.io/developmentseed/charts/eoapi-notifier

# Install specific version
helm install eoapi-notifier oci://ghcr.io/developmentseed/charts/eoapi-notifier --version 1.0.0

# With custom values
helm install eoapi-notifier oci://ghcr.io/developmentseed/charts/eoapi-notifier -f values.yaml
```

## Configuration

```yaml
config:
  sources:
    - type: pgstac
      config:
        connection:
          existingSecret:
            name: "postgresql-credentials"
            keys:
              username: "user"
              password: "password"
              host: "host"
              port: "port"
              database: "dbname"

  outputs:
    - type: mqtt
      config:
        broker_host: mqtt-broker
        broker_port: 1883

    - type: cloudevents
      config:
        source: /eoapi/pgstac
        destination:
          ref:
            apiVersion: messaging.knative.dev/v1
            kind: Broker
            name: my-channel-1
            namespace: serverless

  # Optional: filter events before forwarding (OR across blocks)
  # filters:
  #   - collections: ["sentinel-2-l2a"]
  #     operations: ["create", "replace"]
  #     bbox: [-180, -90, 180, 90]

# Connection credentials should be provided via existing Kubernetes secrets
# Referenced in sources[].config.connection.existingSecret

resources:
  limits:
    cpu: 500m
    memory: 512Mi
  requests:
    cpu: 100m
    memory: 128Mi
```

## Service Account Configuration

The chart supports using a custom service account, which is useful when deploying as a subchart:

```yaml
serviceAccount:
  # Allow parent chart to override the service account name
  name: ""
  # When name is provided, use it instead of creating a new one
  create: true
```

### Usage in Parent Chart

```yaml
# charts/eoapi/values.yaml
eoapi-notifier:
  serviceAccount:
    name: eoapi  # Use the parent chart's service account
    create: false
```

## KNative SinkBinding Support

The chart automatically creates KNative SinkBinding resources for CloudEvents outputs, resolving object references to URLs via the `K_SINK` environment variable.

### Configuration

```yaml
outputs:
  - type: cloudevents
    config:
      source: /eoapi/pgstac
      destination:
        ref:
          apiVersion: messaging.knative.dev/v1
          kind: Broker
          name: my-broker
          namespace: default  # optional
```

CloudEvent `type` values follow OGC PubSub (`org.ogc.api.collection.item.create`, etc.); they are derived from the pgSTAC operation, not from output config.
